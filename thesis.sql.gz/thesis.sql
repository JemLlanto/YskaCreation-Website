-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2024 at 12:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `chatid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `chatroomid` int(11) NOT NULL,
  `message` varchar(200) NOT NULL,
  `chat_date` datetime NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`chatid`, `userid`, `chatroomid`, `message`, `chat_date`, `image`) VALUES
(18, 18, 10, 'asd', '2024-06-25 04:44:16', ''),
(19, 17, 10, 'asd', '2024-06-25 04:44:31', ''),
(20, 18, 10, 'asd', '2024-06-25 11:25:15', ''),
(24, 18, 10, '', '2024-06-25 11:39:49', '../uploads/667a3c0505ba22.03117185.jpg'),
(25, 18, 10, '', '2024-06-25 11:41:32', '../uploads/667a3c6c9d8447.83662030.jpg'),
(26, 17, 10, '', '2024-06-25 12:02:41', '../uploads/667a41617c5fa2.10906527.jpg'),
(27, 22, 14, 'asd', '2024-06-25 12:08:25', ''),
(28, 22, 14, 'asdasd', '2024-06-25 12:08:28', ''),
(29, 22, 14, 'asd', '2024-06-25 12:09:14', ''),
(30, 17, 14, 'asd', '2024-06-25 12:11:30', ''),
(31, 22, 14, '', '2024-06-25 12:17:10', '../uploads/667a44c6578d11.55830281.jpg'),
(32, 25, 17, 'Kamusta ka na', '2024-06-26 18:05:34', ''),
(33, 25, 17, 'Ok lang', '2024-06-26 18:07:02', ''),
(34, 25, 17, 'Hnido', '2024-06-26 18:07:18', ''),
(35, 25, 17, 'A', '2024-06-26 18:07:37', ''),
(36, 25, 17, 'Lesgo', '2024-06-26 18:07:42', ''),
(37, 17, 17, 'Bobo k', '2024-06-26 18:07:50', ''),
(38, 17, 17, 'Omsim', '2024-06-26 18:08:18', ''),
(39, 25, 17, 'Legit', '2024-06-26 18:08:22', ''),
(40, 25, 17, '', '2024-06-26 18:08:33', '../uploads/667be8a15e3a80.91232395.jpg'),
(41, 28, 20, 'ssadasdsad', '2024-09-29 16:34:35', ''),
(42, 28, 20, 'kupal', '2024-09-29 17:43:13', ''),
(43, 28, 20, 'baggoooooooooooooooooooooooooooooooooo', '2024-09-29 17:43:19', ''),
(44, 28, 20, 'asdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasdasdsadsadadasda', '2024-09-29 17:43:29', ''),
(45, 28, 20, 'asdsadsadasdasd', '2024-09-29 17:43:34', ''),
(46, 28, 20, 'asdasdsadasdsadasdsadasdasdasdasd', '2024-09-29 17:43:38', '');

-- --------------------------------------------------------

--
-- Table structure for table `chatroom`
--

CREATE TABLE `chatroom` (
  `chatroomid` int(11) NOT NULL,
  `chat_name` varchar(60) NOT NULL,
  `date_created` datetime NOT NULL,
  `chat_password` varchar(30) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chatroom`
--

INSERT INTO `chatroom` (`chatroomid`, `chat_name`, `date_created`, `chat_password`, `userid`) VALUES
(3, 'Yskah', '2017-09-11 13:21:24', '', 1),
(9, 'Jambik', '2024-06-25 04:42:24', '', 1),
(10, 'Jem', '2024-06-25 04:44:08', '', 1),
(14, 'Dave', '2024-06-25 04:54:01', '', 1),
(17, 'Jm', '2024-06-26 16:33:17', '', 1),
(18, 'john kenneth', '2024-06-26 18:19:47', '', 1),
(19, 'eugene', '2024-06-26 18:21:36', '', 1),
(20, 'Jempogi', '2024-09-29 11:57:24', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `chat_member`
--

CREATE TABLE `chat_member` (
  `chat_memberid` int(11) NOT NULL,
  `chatroomid` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `chat_member`
--

INSERT INTO `chat_member` (`chat_memberid`, `chatroomid`, `userid`) VALUES
(1, 1, 2),
(2, 2, 3),
(3, 3, 1),
(8, 9, 0),
(9, 10, 0),
(13, 14, 1),
(14, 15, 1),
(15, 16, 1),
(16, 17, 1),
(17, 18, 1),
(18, 19, 1),
(19, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `notification_table`
--

CREATE TABLE `notification_table` (
  `notification_id` int(15) NOT NULL,
  `to_admin` int(11) NOT NULL DEFAULT 0,
  `user_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `order_number` int(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_table`
--

INSERT INTO `notification_table` (`notification_id`, `to_admin`, `user_id`, `title`, `description`, `status`, `image_file`, `order_number`, `date`) VALUES
(135, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details', 'Unread', '', 0, '2024-06-25 20:09:14'),
(136, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 3909074', 'Unread', '', 0, '2024-06-25 20:11:37'),
(137, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 6739435', 'Unread', '', 0, '2024-06-26 03:24:36'),
(138, 0, 29, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details', 'Unread', '', 0, '2024-06-26 03:24:45'),
(139, 0, 29, 'Order Delivered', 'Your Order has been Delivered by the Seller. Click for more details', 'Unread', '', 0, '2024-06-26 03:25:24'),
(140, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 2599400', 'Unread', '', 0, '2024-06-26 03:38:34'),
(141, 0, 29, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details Order Number: 2599400', 'Unread', '', 0, '2024-06-26 03:38:40'),
(142, 0, 29, 'Order Shipped', 'Your Order has been Shipped by the Seller. Click for more details Order Number: 2599400', 'Unread', '', 0, '2024-06-26 03:38:42'),
(143, 0, 29, 'Order Delivered', 'Your Order has been Delivered by the Seller. Click for more details Order Number: 9439046', 'Unread', '', 0, '2024-06-26 03:38:44'),
(144, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 8585683', 'Unread', '', 0, '2024-06-26 03:45:41'),
(145, 0, 29, '', ' Order Number: 3173274', '', '', 0, '2024-06-26 05:16:57'),
(146, 0, 29, '', ' Order Number: 4479816', '', '', 0, '2024-06-26 05:17:57'),
(147, 0, 29, '', ' Order Number: 5028342', '', '', 0, '2024-06-26 05:20:41'),
(148, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 7823083', 'Unread', '', 0, '2024-06-26 05:39:52'),
(149, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 5940955', 'Unread', '', 0, '2024-06-26 05:40:28'),
(150, 0, 29, '', ' Order Number: 7660026', '', '', 0, '2024-06-26 05:41:26'),
(151, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 4285283', 'Unread', '', 0, '2024-06-26 07:12:55'),
(152, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 2845416', 'Unread', '', 0, '2024-06-26 07:15:41'),
(153, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 5380535', 'Unread', '', 0, '2024-06-26 07:16:09'),
(154, 0, 29, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 3074229', 'Unread', '', 0, '2024-06-26 07:18:03'),
(155, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 1197063', 'Unread', '', 0, '2024-06-26 08:43:41'),
(156, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 5821550', 'Unread', '', 0, '2024-06-26 08:57:59'),
(157, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 5507337', 'Unread', '', 0, '2024-06-26 08:59:50'),
(158, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 7424135', 'Unread', '', 0, '2024-06-26 09:05:40'),
(159, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 3015677', 'Unread', '', 0, '2024-06-26 09:17:04'),
(160, 0, 36, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details Order Number: 3015677', 'Unread', '', 0, '2024-06-26 09:22:38'),
(161, 0, 36, 'Order Shipped', 'Your Order has been Shipped by the Seller. Click for more details Order Number: 3015677', 'Unread', '', 0, '2024-06-26 09:22:51'),
(162, 0, 36, 'Order Delivered', 'Your Order has been Delivered by the Seller. Click for more details Order Number: 4067641', 'Unread', '', 0, '2024-06-26 09:22:55'),
(163, 0, 36, 'Order Delivered', 'Your Order has been Delivered by the Seller. Click for more details Order Number: 9726393', 'Unread', '', 0, '2024-06-26 09:23:03'),
(164, 0, 36, 'Order Delivered', 'Your Order has been Delivered by the Seller. Click for more details Order Number: 6416442', 'Unread', '', 0, '2024-06-26 09:23:59'),
(165, 0, 29, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details Order Number: 9414784', 'Unread', '', 0, '2024-06-26 09:40:09'),
(166, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 9076524', 'Unread', '', 0, '2024-06-26 09:41:14'),
(167, 0, 29, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details Order Number: 4285283', 'Unread', '', 0, '2024-06-26 09:45:13'),
(168, 0, 29, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details Order Number: 3074229', 'Unread', '', 0, '2024-06-26 09:54:52'),
(169, 0, 36, 'Order Confirm', 'Your Order has been Confirm by the Seller. Click for more details Order Number: 1197063', 'Unread', '', 0, '2024-06-26 09:54:55'),
(170, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 6858527', 'Unread', '', 0, '2024-06-26 09:59:36'),
(171, 0, 36, 'Order Placed', 'Your Order has been placed successfully. Click for more details Order Number: 5773605', 'Unread', '', 0, '2024-06-26 10:03:52'),
(172, 0, 39, 'Order Placed', 'Your Order has been placed successfully. Click for more details', 'Unread', '', 1211382, '2024-09-29 09:24:24'),
(173, 1, 39, 'New Order', 'New order from Jempogi. Click for more details', '', '', 1211382, '2024-09-29 09:24:24'),
(174, 0, 39, 'Order Placed', 'Your Order has been placed successfully. Click for more details', 'Unread', '', 5104049, '2024-09-29 09:27:05'),
(175, 1, 39, 'New Order', 'New order from Jempogi. Click for more details', '', '', 5104049, '2024-09-29 09:27:05'),
(176, 0, 39, 'Order Placed', 'Your Order has been placed successfully. Click for more details', 'Unread', '', 7868265, '2024-09-29 09:30:51'),
(177, 1, 39, 'New Order', 'New order from Jempogi. Click for more details', '', '', 7868265, '2024-09-29 09:30:51'),
(178, 0, 39, 'Order Placed', 'Your Order has been placed successfully. Click for more details', 'Unread', '', 8537234, '2024-09-29 09:39:54'),
(179, 1, 39, 'New Order', 'New order from Jempogi. Click for more details', '', '', 8537234, '2024-09-29 09:39:54');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(15) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(15) NOT NULL,
  `variant_ids` varchar(255) NOT NULL,
  `variant_content_ids` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `total` int(15) NOT NULL,
  `status` enum('Pending','Shipping','Shipped','Delivered') DEFAULT 'Pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `delivered_date` timestamp NULL DEFAULT current_timestamp(),
  `order_number` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `user_id`, `product_id`, `variant_ids`, `variant_content_ids`, `product_name`, `image_file`, `price`, `quantity`, `total_price`, `total`, `status`, `order_date`, `delivered_date`, `order_number`) VALUES
(99, 213, 33, 2, '12,13', '23,20', 'Glass Art', '6671a63da6d71.jpg', 439, 1, 439.00, 439, 'Delivered', '2024-06-25 15:36:04', '2024-06-25 15:36:04', 9868655),
(100, 214, 33, 1, '9,10,11', '17,12,15', 'Button Pin', '6671a7f0f33e7.jpg', 91, 1, 91.00, 229, 'Delivered', '2024-06-25 15:36:13', '2024-06-25 15:36:13', 8431844),
(101, 215, 33, 1, '9,10,11', '17,12,14', 'Button Pin', '6671a7f0f33e7.jpg', 138, 1, 138.00, 229, 'Delivered', '2024-06-25 15:36:13', '2024-06-25 15:36:13', 8431844),
(102, 217, 29, 1, '9,10,11', '17,12,14', 'Button Pin', '6671a7f0f33e7.jpg', 138, 2, 276.00, 276, 'Delivered', '2024-06-25 18:17:09', '2024-06-25 18:23:37', 2140204),
(103, 218, 29, 9, '14,15', '25,28', 'Phone Case', '6677c28d7d1dd.jpg', 250, 1, 250.00, 250, 'Delivered', '2024-06-25 18:25:53', '2024-06-25 18:41:41', 7828873),
(104, 219, 29, 2, '12,13', '23,19', 'Glass Art', '6671a63da6d71.jpg', 289, 1, 289.00, 289, 'Delivered', '2024-06-25 18:42:43', '2024-06-25 18:42:43', 6878377),
(106, 221, 29, 2, '12,13', '23,18', 'Glass Art', '6671a63da6d71.jpg', 339, 1, 339.00, 339, 'Delivered', '2024-06-25 20:11:37', '2024-06-25 20:11:37', 3909074),
(107, 222, 29, 2, '12,13', '23,19', 'Glass Art', '6671a63da6d71.jpg', 289, 1, 289.00, 289, 'Delivered', '2024-06-26 03:24:36', '2024-06-26 03:25:24', 6739435),
(108, 225, 29, 1, '9,10,11', '17,12,15', 'Button Pin', '6671a7f0f33e7.jpg', 91, 1, 91.00, 91, 'Delivered', '2024-06-26 03:38:34', '2024-06-26 03:38:34', 2599400),
(109, 226, 29, 2, '12,13', '21,19', 'Glass Art', '6671a63da6d71.jpg', 249, 1, 249.00, 249, 'Shipping', '2024-06-26 03:45:41', '2024-06-26 03:45:41', 8585683),
(128, 276, 29, 9, '14,15', '25,28', 'Phone Case', '6677c28d7d1dd.jpg', 250, 1, 250.00, 250, 'Shipping', '2024-06-26 06:57:05', '2024-06-26 06:57:05', 9414784),
(134, 288, 29, 9, '14,15', '25,28', 'Phone Case', '6677c28d7d1dd.jpg', 250, 1, 250.00, 250, 'Shipping', '2024-06-26 07:12:55', '2024-06-26 07:12:55', 4285283),
(135, 289, 29, 1, '9,10,11', '17,12,15', 'Button Pin', '6671a7f0f33e7.jpg', 91, 1, 91.00, 91, 'Shipping', '2024-06-26 07:15:41', '2024-06-26 07:15:41', 2845416),
(136, 286, 29, 2, '12,13', '21,18', 'Glass Art', '6671a63da6d71.jpg', 299, 1, 299.00, 837, 'Shipping', '2024-06-26 07:16:09', '2024-06-26 07:16:09', 5380535),
(137, 287, 29, 2, '12,13', '21,19', 'Glass Art', '6671a63da6d71.jpg', 249, 1, 249.00, 837, 'Shipping', '2024-06-26 07:16:09', '2024-06-26 07:16:09', 5380535),
(138, 290, 29, 2, '12,13', '23,19', 'Glass Art', '6671a63da6d71.jpg', 289, 1, 289.00, 837, 'Shipping', '2024-06-26 07:16:09', '2024-06-26 07:16:09', 5380535),
(139, 291, 29, 9, '14,15', '25,28', 'Phone Case', '6677c28d7d1dd.jpg', 250, 1, 250.00, 250, 'Shipping', '2024-06-26 07:18:03', '2024-06-26 07:18:03', 3074229),
(140, 292, 36, 2, '12,13', '23,19', 'Glass Art', '6671a63da6d71.jpg', 289, 1, 289.00, 289, 'Shipping', '2024-06-26 08:43:41', '2024-06-26 08:43:41', 1197063),
(144, 296, 36, 1, '9,10,11', '17,12,15', 'Button Pin', '6671a7f0f33e7.jpg', 91, 1, 91.00, 241, 'Shipped', '2024-06-26 09:17:04', '2024-06-26 09:17:04', 3015677),
(148, 301, 39, 9, '14,15', '25,26', 'Phone Case', '6677c28d7d1dd.jpg', 300, 2, 600.00, 750, 'Pending', '2024-09-29 09:24:24', '2024-09-29 09:24:24', 1211382),
(149, 303, 39, 9, '14,15', '24,28', 'Phone Case', '6677c28d7d1dd.jpg', 279, 5, 1395.00, 1545, 'Pending', '2024-09-29 09:27:05', '2024-09-29 09:27:05', 5104049),
(150, 304, 39, 1, '9,10,11', '17,11,15', 'Button Pin', '6671a7f0f33e7.jpg', 120, 1, 120.00, 270, 'Pending', '2024-09-29 09:30:51', '2024-09-29 09:30:51', 7868265),
(151, 305, 39, 2, '12,13', '21,18', 'Glass Art', '6671a63da6d71.jpg', 299, 1, 299.00, 890, 'Pending', '2024-09-29 09:39:54', '2024-09-29 09:39:54', 8537234),
(152, 306, 39, 1, '9,10,11', '17,11,13', 'Button Pin', '6671a7f0f33e7.jpg', 147, 3, 441.00, 890, 'Pending', '2024-09-29 09:39:54', '2024-09-29 09:39:54', 8537234);

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` int(15) NOT NULL,
  `product_id` int(15) NOT NULL,
  `user_id` int(15) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `variant_ids` varchar(255) NOT NULL,
  `variant_content_ids` varchar(255) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`order_id`, `product_id`, `user_id`, `product_name`, `image_file`, `price`, `quantity`, `total`, `variant_ids`, `variant_content_ids`, `status`) VALUES
(300, 2, 38, 'Glass Art', '6671a63da6d71.jpg', 289, 1, 289, '12,13', '23,19', 0);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(15) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `hot` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `image_file`, `price`, `description`, `hot`) VALUES
(1, 'Button Pin', '6671a7f0f33e7.jpg', 119, 'Customize/Personalized Button Pin Painting is now available on our shop 💟\r\n\r\nWe accept:\r\n\r\n✨Anime Character (you can request your desired anime character) - face only\r\n\r\n✨Faceless Vector Art (up to 2 heads only/couple)\r\n\r\n✨ Dog and Cat\r\n\r\nMessage me for more details 💌 We ship nationwide 🍃', 0),
(2, 'Glass Art', '6671a63da6d71.jpg', 299, 'Customize/Personalized Button Pin Painting is now available on our shop 💟\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nWe accept:\r\n\r\n\r\n\r\n\r\n✨Anime Character (you can request your desired anime character) - face only\r\n\r\n✨Faceless Vector Art (up to 2 heads only/couple)\r\n\r\n✨ Dog and Cat\r\n\r\nMessage me for more details 💌 We ship nationwide 🍃', 0),
(9, 'Phone Case', '6677c28d7d1dd.jpg', 199, 'KINDLY READ THE GUIDELINES BEFORE CHECKING OUT:\r\n\r\n\r\nGuidelines:\r\n\r\n🏷 Please indicate your phone brand/model and your desired design or anime character on the \"message\".\r\n\r\n\r\n🏷 If you have a specific design, message me directly and send the picture on our message  or you can suggest that I\'m the one who choose your own design.\r\n\r\n\r\n🏷 The product is listed as \"Pre-order\", and it will be shipped out on or before 20 - 30 days. It means that I only accept Pre-order and not rush orders because it\'s hand made and customized, just message me if I\'m available for rush orders.\r\n\r\n\r\n🏷 The painting will take 1 week to a maximum of 3 weeks, depending on the quantity or the orders.\r\n\r\n\r\n‼️STRICTLY NO CANCELLATION OF ORDERS‼️\r\n\r\n\r\nProduct information/inclusion:\r\n\r\n✨ Either shockproof clear case/clear jelly case depends on the availability\r\n\r\n✨ Hand Painted using Acrylic paint\r\n\r\n✨ The Case and the design is durable because I used sealer to protect the paint.\r\n\r\n✨ with sticker\r\n\r\n\r\nMaterials used:\r\n\r', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_samples`
--

CREATE TABLE `product_samples` (
  `sample_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_samples`
--

INSERT INTO `product_samples` (`sample_id`, `product_id`, `image_file`) VALUES
(12, 2, '666e708192da5.jpg'),
(15, 2, '6672805af2cf6.jpg'),
(16, 2, '66728fcf9187b.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `product_id` int(15) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` int(15) NOT NULL,
  `item_sold` int(15) NOT NULL,
  `total` int(15) NOT NULL,
  `sale_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`product_id`, `product_name`, `price`, `item_sold`, `total`, `sale_id`) VALUES
(2, 'Glass Art', 299, 0, 0, 1),
(1, 'Button Pin', 119, 0, 0, 3),
(9, 'Phone Case', 199, 0, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(150) NOT NULL,
  `uname` varchar(60) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `access` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `uname`, `photo`, `access`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', '', 1),
(17, 'Jambik', '$2y$10$VpubD.7cg3gLKaasKSAHsuQzoeNFqSohsD3WwP1vfDecDNNbsTwXC', 'John Victor', '', 1),
(18, 'Jem', '$2y$10$eiZ1heH4d7JLsKbuXMWnmO417xbukmRwfuS2sAMl6Fb.1IeUK8vyW', 'Jem', '', 2),
(22, 'Dave', '$2y$10$jitZ9FEXWsSSHvNmKoVnreO69YjWB7REBfTcndZQLpgU4/6chXsVG', 'John Kenneth', '', 2),
(25, 'Jm', '$2y$10$pVecZ0OpRD7pvYyQq6thtu0xzytFyCwukc1BzPvscE.5l4sAq.4ru', 'John Mark', '', 2),
(26, 'john kenneth', '$2y$10$jW5npqS8uG5yO0iRkGRXNeHEPsv2AWSNCaUDNrj8RtsMuZSpaD1cS', 'John Kenneth', '', 2),
(27, 'eugene', '$2y$10$gE3jwmr6CGrNcfxAGY0Hfuy1oCFBpexRLKHCeUStXSps2WaDbBKEi', 'Joharie', '', 2),
(28, 'Jempogi', '$2y$10$qUE5dWQrxoDX7flAQwhFyevo0i/W11h2ZNcjRfwGOgmmmlR/8QEsu', 'John Kenneth', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(50) NOT NULL,
  `is_admin` tinyint(1) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `sex` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `blockLot` varchar(100) NOT NULL,
  `subdivision` varchar(255) NOT NULL,
  `barangay` varchar(255) NOT NULL,
  `island_group` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `zip` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `image_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `is_admin`, `first_name`, `last_name`, `sex`, `phone`, `blockLot`, `subdivision`, `barangay`, `island_group`, `city`, `province`, `zip`, `username`, `email`, `password`, `image_file`) VALUES
(28, 1, 'John Victor', 'Silva', 'male', '123123123', 'Blk 69', 'Caririsa', 'Punta 1', 'Luzon', 'Tanza', 'Cavite', '4108', 'Jambik', 'johnvictor@gmail.com', '$2y$10$VpubD.7cg3gLKaasKSAHsuQzoeNFqSohsD3WwP1vfDecDNNbsTwXC', 'default-profile.jpg'),
(29, 0, 'Jem', 'Llanto', 'female', '123123123', '250 Ac. Mercado St.', 'Casa Amaya Subdivision', 'Punta 1', 'Mindanao', 'Rosario', 'Cavite', '4018', 'Jem', 'jem@asd.com', '$2y$10$eiZ1heH4d7JLsKbuXMWnmO417xbukmRwfuS2sAMl6Fb.1IeUK8vyW', 'default-profile.jpg'),
(33, 0, 'John Kenneth', 'Tan', 'female', '123123123', 'Block 2 Lot 2 Phase 2', 'Casa Amaya Subdivision', 'Amaya I', 'Visayas', 'Tanza', 'Cavite', '4108', 'Dave', 'asd@asdassd.com', '$2y$10$jitZ9FEXWsSSHvNmKoVnreO69YjWB7REBfTcndZQLpgU4/6chXsVG', 'default-profile.jpg'),
(36, 0, 'John Mark', 'Sallao', 'male', '09123456789', 'Blk 143', 'Calibuyo', 'Calibuyo', 'Luzon', 'Tanza', 'Cavite', '4108', 'Jm', 'tan@gmail.comcs', '$2y$10$pVecZ0OpRD7pvYyQq6thtu0xzytFyCwukc1BzPvscE.5l4sAq.4ru', '667be8f228ca8.jpg'),
(37, 0, 'John Kenneth', 'Tan', 'male', '09123456789', 'blk 2 ph2 lot 2', 'casa amaya sub', 'amaya i', 'Visayas', 'Tanza', 'Cavite', '4108', 'john kenneth', 'tan@gmail.cohvgh', '$2y$10$jW5npqS8uG5yO0iRkGRXNeHEPsv2AWSNCaUDNrj8RtsMuZSpaD1cS', 'default-profile.jpg'),
(38, 0, 'Joharie', 'Sainoding', 'male', '09876', 'cvsu trce', 'tanza', 'gentri', 'Luzon', 'tanza', 'cavite', '4108', 'Eugene', 'Joharie.Sainoding@cvsu.edu.ph', '$2y$10$vcsRMAnCOCie8C0pM8QY7OgxsbFiUF8xe0AFKIpChSKB0c408x9mS', 'default-profile.jpg'),
(39, 0, 'Jem', 'Llanto', 'female', '+639123456789', 'Wawa 2', 'xzczxc', 'zxczxczxczxc', 'Choose...', 'Tanza', 'Cavite', '4108', 'Jempogi', 'tanxzczxcxzc@gmail.com', '$2y$10$/HvYnlwqd6HwZeK79k1Ljud15g7lhyJMCX6bW/3LML1.Tqy.CJ3vm', '66f923ea9dfd7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `variant_content`
--

CREATE TABLE `variant_content` (
  `variant_content_id` int(15) NOT NULL,
  `variant_id` int(15) NOT NULL,
  `option` varchar(100) NOT NULL,
  `price` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `variant_content`
--

INSERT INTO `variant_content` (`variant_content_id`, `variant_id`, `option`, `price`) VALUES
(11, 10, 'Anime', 59),
(12, 10, 'faceless', 30),
(13, 11, '2 heads', 39),
(14, 11, '3 heads', 59),
(15, 11, '1 Head', 12),
(17, 9, '4x3', 49),
(18, 13, 'Anime Simple', 249),
(19, 13, 'Faceless Vector Art', 199),
(20, 13, 'Anime Detailed', 349),
(21, 12, '4x6', 50),
(22, 12, '4x4', 40),
(23, 12, '6x8', 90),
(24, 14, 'Anime', 129),
(25, 14, 'Vector Art', 100),
(26, 15, 'One', 50),
(27, 15, 'Two', 100),
(28, 15, '3', 150);

-- --------------------------------------------------------

--
-- Table structure for table `variant_table`
--

CREATE TABLE `variant_table` (
  `variant_id` int(15) NOT NULL,
  `product_id` int(15) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `variant_table`
--

INSERT INTO `variant_table` (`variant_id`, `product_id`, `name`) VALUES
(1, 0, 'asdasd'),
(2, 0, 'hahaha'),
(9, 1, 'size'),
(10, 1, 'Style'),
(11, 1, 'Heads'),
(12, 2, 'Size'),
(13, 2, 'Style'),
(14, 9, 'Style'),
(15, 9, 'Heads');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`chatid`);

--
-- Indexes for table `chatroom`
--
ALTER TABLE `chatroom`
  ADD PRIMARY KEY (`chatroomid`);

--
-- Indexes for table `chat_member`
--
ALTER TABLE `chat_member`
  ADD PRIMARY KEY (`chat_memberid`);

--
-- Indexes for table `notification_table`
--
ALTER TABLE `notification_table`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_samples`
--
ALTER TABLE `product_samples`
  ADD PRIMARY KEY (`sample_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sale_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `variant_content`
--
ALTER TABLE `variant_content`
  ADD PRIMARY KEY (`variant_content_id`);

--
-- Indexes for table `variant_table`
--
ALTER TABLE `variant_table`
  ADD PRIMARY KEY (`variant_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `chatid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `chatroom`
--
ALTER TABLE `chatroom`
  MODIFY `chatroomid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `chat_member`
--
ALTER TABLE `chat_member`
  MODIFY `chat_memberid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `notification_table`
--
ALTER TABLE `notification_table`
  MODIFY `notification_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product_samples`
--
ALTER TABLE `product_samples`
  MODIFY `sample_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sale_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `variant_content`
--
ALTER TABLE `variant_content`
  MODIFY `variant_content_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `variant_table`
--
ALTER TABLE `variant_table`
  MODIFY `variant_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
